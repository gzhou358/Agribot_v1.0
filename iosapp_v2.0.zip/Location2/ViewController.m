//
//  ViewController.m
//  Location2
//
//  Created by guang zhou on 5/19/15.
//  Copyright (c) 2015 guang zhou. All rights reserved.
//

#import "ViewController.h"
#define IS_OS_8_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
#define mindistance 3
#define headangular 20

@interface ViewController ()
@property Boolean execution;
@property Boolean hasobstacle;
@property NSString* premsg;

@property double glatitude;
@property double glongitude;

@property CLLocationManager *locationManager;
@property CLLocation *currentLocation;
@property CLHeading *Heading;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initLocation];
    self.mapView.showsUserLocation = YES;
    [self.mapView setZoomEnabled:YES];
    [self.mapView setScrollEnabled:YES];
    UILongPressGestureRecognizer *lpgr = [[UILongPressGestureRecognizer alloc]
                                          initWithTarget:self action:@selector(handleLongPress:)];
    lpgr.minimumPressDuration = 1.0; //user needs to press for 2 seconds
    [self.mapView addGestureRecognizer:lpgr];
    [self initNetworkCommunication];
    self.execution = false;
    _hasobstacle = false;
    _premsg = @"";
    self.glatitude = 0;
    self.glongitude = 0;
    [self startTimedTask];
    self.input.delegate = self;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardFrameDidChange:) name:UIKeyboardWillChangeFrameNotification object:nil];
}
//hide keyboard by return
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.input resignFirstResponder];
    return YES;
}
//hide keyboard by touch outside
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [[event allTouches] anyObject];
    if ([_input isFirstResponder] && [touch view] != _input) {
        [_input resignFirstResponder];
    }
    [super touchesBegan:touches withEvent:event];
}
//keyboard wont hide textfield
- (void)keyboardFrameDidChange:(NSNotification *)notification
{
    CGRect keyboardEndFrame = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGRect keyboardBeginFrame = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
    UIViewAnimationCurve animationCurve = [[[notification userInfo] objectForKey:UIKeyboardAnimationCurveUserInfoKey] integerValue];
    NSTimeInterval animationDuration = [[[notification userInfo] objectForKey:UIKeyboardAnimationDurationUserInfoKey] integerValue];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:animationCurve];
    CGRect newFrame = self.view.frame;
    CGRect keyboardFrameEnd = [self.view convertRect:keyboardEndFrame toView:nil];
    CGRect keyboardFrameBegin = [self.view convertRect:keyboardBeginFrame toView:nil];
    newFrame.origin.y -= (keyboardFrameBegin.origin.y - keyboardFrameEnd.origin.y);
    self.view.frame = newFrame;
    [UIView commitAnimations];
}

//setup gps point location by long touch.
- (void)handleLongPress:(UIGestureRecognizer *)gestureRecognizer
{
    if (gestureRecognizer.state != UIGestureRecognizerStateBegan)
        return;
    CGPoint touchPoint = [gestureRecognizer locationInView:self.mapView];
    CLLocationCoordinate2D touchMapCoordinate =
    [self.mapView convertPoint:touchPoint toCoordinateFromView:self.mapView];
    MKPointAnnotation *annot = [[MKPointAnnotation alloc] init];
    annot.coordinate = touchMapCoordinate;
    self.glatitude = touchMapCoordinate.latitude;
    self.glongitude = touchMapCoordinate.longitude;
    NSLog([NSString stringWithFormat:@"%.8f", touchMapCoordinate.latitude]);
    NSLog([NSString stringWithFormat:@"%.8f", touchMapCoordinate.longitude]);
    [self.mapView addAnnotation:annot];
}
//init network
- (void)initNetworkCommunication {
    CFReadStreamRef readStream;
    CFWriteStreamRef writeStream;
    CFStreamCreatePairWithSocketToHost(NULL, (CFStringRef)@"192.168.1.1", 80, &readStream, &writeStream);
    inputStream = (__bridge  NSInputStream *)readStream;
    outputStream = (__bridge  NSOutputStream *)writeStream;
    [inputStream setDelegate:self];
    [outputStream setDelegate:self];
    [inputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [outputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [inputStream open];
    [outputStream open];
}
//tcp in/out handle
- (void)stream:(NSStream *)theStream handleEvent:(NSStreamEvent)streamEvent {
    switch (streamEvent) {
        case NSStreamEventOpenCompleted:
            NSLog(@"Stream opened");
            break;
        case NSStreamEventHasBytesAvailable:
            NSLog(@"Stream has bytes avaiable");
            if (theStream == inputStream) {
                uint8_t buffer[1024];
                int len;
                while ([inputStream hasBytesAvailable]) {
                    len = [inputStream read:buffer maxLength:sizeof(buffer)];
                    if (len > 0) {
                        NSString *output = [[NSString alloc] initWithBytes:buffer length:len encoding:NSASCIIStringEncoding];
                        //if msg from board is number then to global variable.
                        if (nil != output) {
                            NSLog(@"server said: %@", output);
                            if([output isEqualToString:@"hasobstacle"]){
                                _hasobstacle = true;
                            }
                            if([output isEqualToString:@"noobstacle"]){
                                _hasobstacle = false;
                            }
                            NSString *response = [@"smsg: " stringByAppendingString: output];
                            self.ouput.text = response;
                        }
                    }
                }
            }
            break;
        case NSStreamEventErrorOccurred:
            NSLog(@"Can not connect to the host!");
            break;
        case NSStreamEventEndEncountered:
            break;
        default:
            NSLog(@"Unknown event");
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Failed to Get Your Location"
                               delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    self.longitude.text = [NSString stringWithFormat:@"%.8f", newLocation.coordinate.longitude];
    self.latitude.text = [NSString stringWithFormat:@"%.8f", newLocation.coordinate.latitude];
}

-(void)initLocation{
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    if(IS_OS_8_OR_LATER){
        NSUInteger code = [CLLocationManager authorizationStatus];
        if (code == kCLAuthorizationStatusNotDetermined && ([self.locationManager respondsToSelector:@selector(requestAlwaysAuthorization)] || [self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)])) {
            // choose one request according to your business.
            if([[NSBundle mainBundle] objectForInfoDictionaryKey:@"NSLocationAlwaysUsageDescription"]){
                [self.locationManager requestAlwaysAuthorization];
            } else if([[NSBundle mainBundle] objectForInfoDictionaryKey:@"NSLocationWhenInUseUsageDescription"]) {
                [self.locationManager  requestWhenInUseAuthorization];
            } else {
                NSLog(@"Info.plist does not contain NSLocationAlwaysUsageDescription or NSLocationWhenInUseUsageDescription");
            }
        }
    }
    [self.locationManager startUpdatingLocation];
    [self.locationManager startUpdatingHeading];
}

-(void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading {
    self.trueHeading.text = [NSString stringWithFormat:@"%f", newHeading.trueHeading];
}

- (IBAction)setMap:(id)sender {
    switch (((UISegmentedControl *) sender).selectedSegmentIndex) {
        case 0:
            self.mapView.mapType = MKMapTypeStandard;
            break;
        case 1:
            self.mapView.mapType = MKMapTypeSatellite;
            break;
        case 2:
            self.mapView.mapType = MKMapTypeHybrid;
            break;
        default:
            break;
    }
}

- (IBAction)setCar:(id)sender {
    switch (((UISegmentedControl *) sender).selectedSegmentIndex) {
        case 0:
            [self sendtoCar: @"servoL"];
            break;
        case 1:
            [self sendtoCar: @"servoF"];
            break;
        case 2:
            [self sendtoCar: @"servoR"];
            break;
        case 3:
            self.execution = true;
            break;
        case 4:
            //only avoid obstacle.
            [self sendtoCar: @"start"];
            break;
        case 5:
            [self sendtoCar: @"start"];
            self.execution = true;
            break;
        default:
            break;
    }
    _premsg = @"";
}

- (IBAction)Forward:(id)sender {
    [self sendtoCar: @"forward"];
}

- (IBAction)TurnL:(id)sender {
    [self sendtoCar: @"turnL"];
}

- (IBAction)TurnR:(id)sender {
    [self sendtoCar: @"turnR"];
}

- (IBAction)Reverse:(id)sender {
    [self sendtoCar: @"rev"];
}

- (IBAction)Stop:(id)sender {
    [self sendtoCar: @"stop"];
    self.execution = false;
}

- (IBAction)sendCmd:(id)sender {
    [self sendtoCar: self.input.text];
}

- (void)sendtoCar:(NSString *)cmd
{
    NSLog(@"send cmd");
    NSString *response = [cmd stringByAppendingString:@"\n"];
    NSData *data = [[NSData alloc] initWithData:[response dataUsingEncoding:NSASCIIStringEncoding]];
    [outputStream write:[data bytes] maxLength:[data length]];
}

//start a periodical task.
- (void)startTimedTask
{
    NSTimer *fiveSecondTimer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(performBackgroundTask) userInfo:nil repeats:YES];
}
//periodical task for gps navigation.
- (void)performBackgroundTask
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        //Do background work
        dispatch_async(dispatch_get_main_queue(), ^{
            //Update UI
            if (self.execution == 1){
                NSLog(_hasobstacle ? @"Yes" : @"No");
                if (!_hasobstacle){
                    if ((self.glongitude == 0) && (self.glatitude == 0)) {
                        self.ouput.text = @"pls setup gps";
                        NSLog(@"pls setup gps");
                    }
                    else {
                        NSLog(@"navigating");
                        double clatitude = [self.latitude.text doubleValue];
                        double clongitude = [self.longitude.text doubleValue];
                        double cr = getr(self.glatitude, self.glongitude, clatitude, clongitude);
                        self.r.text = [NSString stringWithFormat:@"%.8f", cr];
                        double ctheta = gettheta(self.glatitude, self.glongitude, clatitude, clongitude);
                        self.theta.text = [NSString stringWithFormat:@"%.8f", ctheta];
                        [self decision:cr currentTheta:ctheta];
                    }
                }else {
                    NSLog(@"no obstacle! fwd");
                    NSString *thismsg = @"fwd";
                    if(![thismsg isEqualToString:_premsg]){
                        [self sendtoCar: thismsg];
                        _premsg = thismsg;
                    }
                }
            }
        });
    });
}
- (void)decision:(double )cr currentTheta:(double )ctheta
{
    NSString *thismsg;
    if (cr>mindistance){
        double disa = cycledistance([self.trueHeading.text doubleValue], ctheta);
        double disb = cycledistance(ctheta, [self.trueHeading.text doubleValue]);
        if ((disa < disb)&&(disa>headangular)){
            thismsg = @"turnL";
        }
        else if ((disb < disa)&&(disb>headangular)){
            thismsg = @"turnR";
        }
        else {
            thismsg = @"forward";
        }
    }
    else {
        thismsg = @"stop";
    }
    if(![thismsg isEqualToString:_premsg]){
        [self sendtoCar: thismsg];
        _premsg = thismsg;
    }
}
//angular distance in a cycle
double cycledistance(double a, double b)
{
    if (a-b >0 ){
        return a-b;
    }
    else {return a+360-b;}
}
double getr(double a1, double g1, double a2, double g2)
{
    a1 = a1*3.14159265359/180;
    g1 = g1*3.14159265359/180;
    a2 = a2*3.14159265359/180;
    g2 = g2*3.14159265359/180;
    double fi = acos(cos(a1)*cos(a2)*cos(g2-g1)+sin(a1)*sin(a2));
    return 6371000*fi;
}
double gettheta(double a1, double g1, double a2, double g2)
{
    double r = getr(a1, g1, a2, g2);
    double d = getr(a1, g1, a2, g1);
    double tmp = acos(d/r)*180/3.14159265359;
    double theta =0;
    if(a1>a2){
        if(g1>g2){
            theta = 360-tmp;
        }
        else{
            theta = tmp;
        }
    }
    else {
        if(g1>g2){
            theta = tmp + 180;
        }
        else{
            theta = 180 - tmp;
        }
    }
    return 360-theta;
}
- (BOOL)isInteger:(NSString *)toCheck {
    if([toCheck intValue] != 0) {
        return true;
    } else if([toCheck isEqualToString:@"0"]) {
        return true;
    } else {
        return false;
    }
}
@end
