//
//  AppDelegate.h
//  tcpclient
//
//  Created by guang zhou on 5/20/15.
//  Copyright (c) 2015 guang zhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

