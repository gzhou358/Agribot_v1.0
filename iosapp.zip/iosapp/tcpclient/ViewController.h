//
//  ViewController.h
//  tcpclient
//
//  Created by guang zhou on 5/20/15.
//  Copyright (c) 2015 guang zhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
@interface ViewController : UIViewController <NSStreamDelegate, CLLocationManagerDelegate>
{
    NSInputStream *inputStream;
    NSOutputStream *outputStream;
}
@property (weak, nonatomic) IBOutlet UITextField *input;
@property (weak, nonatomic) IBOutlet UILabel *output;

@property (weak, nonatomic) IBOutlet UILabel *longitude;
@property (weak, nonatomic) IBOutlet UILabel *latitude;
@property (weak, nonatomic) IBOutlet UILabel *magneticHeading;
@property (weak, nonatomic) IBOutlet UILabel *trueHeading;

- (IBAction)Sendcommand:(id)sender;
- (IBAction)Forward:(id)sender;
- (IBAction)TurnL:(id)sender;
- (IBAction)TurnR:(id)sender;
- (IBAction)Reverse:(id)sender;
- (IBAction)GetLeft:(id)sender;
- (IBAction)GetRight:(id)sender;
- (IBAction)Stop:(id)sender;
    @end

